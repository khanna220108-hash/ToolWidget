package com.example.todo

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.text.SpannableString
import android.text.Spanned
import android.text.style.StrikethroughSpan
import android.widget.RemoteViews
import android.widget.RemoteViewsService

class WidgetService : RemoteViewsService() {
    override fun onGetViewFactory(intent: Intent): RemoteViewsFactory = Factory(applicationContext)

    private class Factory(val c: Context) : RemoteViewsFactory {
        var items: List<Task> = emptyList()
        override fun onCreate() {}
        override fun onDataSetChanged() { items = Store.load(c) }
        override fun onDestroy() {}
        override fun getCount() = items.size
        override fun getViewAt(p: Int): RemoteViews {
            val t = items[p]
            val v = RemoteViews(c.packageName, R.layout.widget_item)
            val s = SpannableString(t.text)
            if (t.done) s.setSpan(StrikethroughSpan(), 0, s.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            v.setTextViewText(R.id.text, s)
            v.setTextViewText(R.id.check, if (t.done) "✓" else "○")
            v.setTextColor(R.id.check, Color.parseColor(if (t.done) "#5B4BFF" else "#8A86A3"))
            v.setTextColor(R.id.text, Color.parseColor(if (t.done) "#8A86A3" else "#1E1B33"))
            v.setOnClickFillInIntent(R.id.row, Intent().putExtra("id", t.id))
            return v
        }
        override fun getLoadingView(): RemoteViews? = null
        override fun getViewTypeCount() = 1
        override fun getItemId(p: Int) = items[p].id
        override fun hasStableIds() = true
    }
}

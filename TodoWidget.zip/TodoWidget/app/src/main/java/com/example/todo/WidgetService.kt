package com.example.todo

import android.content.Context
import android.content.Intent
import android.text.SpannableString
import android.text.Spanned
import android.text.style.StrikethroughSpan
import android.widget.RemoteViews
import android.widget.RemoteViewsService

class WidgetService : RemoteViewsService() {
    override fun onGetViewFactory(intent: Intent): RemoteViewsFactory = Factory(applicationContext)

    private class Factory(val c: Context) : RemoteViewsFactory {
        var items: List<Task> = emptyList()
        override fun onCreate() {}
        override fun onDataSetChanged() { items = Store.load(c) }
        override fun onDestroy() {}
        override fun getCount() = items.size
        override fun getViewAt(p: Int): RemoteViews {
            val t = items[p]
            val v = RemoteViews(c.packageName, R.layout.widget_item)
            val s = SpannableString(t.text)
            if (t.done) s.setSpan(StrikethroughSpan(), 0, s.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            v.setTextViewText(R.id.text, s)
            v.setImageViewResource(R.id.check, if (t.done) R.drawable.ic_check_on else R.drawable.ic_check_off)
            v.setTextColor(R.id.text, c.getColor(if (t.done) R.color.mute else R.color.ink))
            v.setOnClickFillInIntent(R.id.row, Intent().putExtra("id", t.id))
            return v
        }
        override fun getLoadingView(): RemoteViews? = null
        override fun getViewTypeCount() = 1
        override fun getItemId(p: Int) = items[p].id
        override fun hasStableIds() = true
    }
}

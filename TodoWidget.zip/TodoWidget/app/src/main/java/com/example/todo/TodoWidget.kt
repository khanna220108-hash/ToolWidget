package com.example.todo

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews

class TodoWidget : AppWidgetProvider() {
    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) =
        ids.forEach { update(c, m, it) }

    override fun onReceive(c: Context, i: Intent) {
        super.onReceive(c, i)
        if (i.action == ACTION_TOGGLE) Store.toggle(c, i.getLongExtra("id", 0))
    }

    companion object {
        const val ACTION_TOGGLE = "com.example.todo.TOGGLE"

        fun update(c: Context, m: AppWidgetManager, id: Int) {
            val v = RemoteViews(c.packageName, R.layout.widget)
            v.setRemoteAdapter(R.id.list, Intent(c, WidgetService::class.java))
            v.setEmptyView(R.id.list, R.id.empty)
            val toggle = PendingIntent.getBroadcast(
                c, 0, Intent(c, TodoWidget::class.java).setAction(ACTION_TOGGLE),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE
            )
            v.setPendingIntentTemplate(R.id.list, toggle)
            val open = PendingIntent.getActivity(
                c, 1, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
            )
            v.setOnClickPendingIntent(R.id.add, open)
            v.setOnClickPendingIntent(R.id.title, open)
            val tasks = Store.load(c)
            val done = tasks.count { it.done }
            val hr = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
            v.setTextViewText(R.id.greeting, if (hr < 12) "Good morning" else if (hr < 18) "Good afternoon" else "Good evening")
            v.setTextViewText(R.id.count, "$done of ${tasks.size} done · ${if (tasks.isEmpty()) 0 else done * 100 / tasks.size}%")
            v.setProgressBar(R.id.bar, 100, if (tasks.isEmpty()) 0 else done * 100 / tasks.size, false)
            m.updateAppWidget(id, v)
        }
    }
}

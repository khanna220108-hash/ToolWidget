package com.example.todo

import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class Task(val id: Long, val text: String, val done: Boolean, val level: Int = 1)

object Levels {
    val NAMES = arrayOf("Easy", "Medium", "Hard")
    val COLORS = intArrayOf(R.color.easy, R.color.medium, R.color.hard)
    val ON = intArrayOf(R.drawable.lvl_easy_on, R.drawable.lvl_medium_on, R.drawable.lvl_hard_on)
}

object Store {
    private fun prefs(c: Context) = c.getSharedPreferences("todo", Context.MODE_PRIVATE)

    fun load(c: Context): MutableList<Task> {
        val s = prefs(c).getString("tasks", null)
            ?: return mutableListOf(Task(1, "Plan the day", false, 1), Task(2, "Drink some water", false, 0))
        val a = JSONArray(s)
        return MutableList(a.length()) {
            val o = a.getJSONObject(it)
            Task(o.getLong("id"), o.getString("t"), o.getBoolean("d"), o.optInt("l", 1))
        }
    }

    fun save(c: Context, list: List<Task>) {
        val a = JSONArray()
        list.forEach { a.put(JSONObject().put("id", it.id).put("t", it.text).put("d", it.done).put("l", it.level)) }
        prefs(c).edit().putString("tasks", a.toString()).apply()
        refreshWidgets(c)
    }

    fun toggle(c: Context, id: Long) =
        save(c, load(c).map { if (it.id == id) it.copy(done = !it.done) else it })

    fun refreshWidgets(c: Context) {
        val m = AppWidgetManager.getInstance(c)
        val ids = m.getAppWidgetIds(ComponentName(c, TodoWidget::class.java))
        m.notifyAppWidgetViewDataChanged(ids, R.id.list)
        ids.forEach { TodoWidget.update(c, m, it) }
    }
}

package com.example.todo

import android.app.Activity
import android.graphics.Paint
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : Activity() {
    private var tasks = mutableListOf<Task>()
    private var view = listOf<Task>()
    private var filter = 0
    private lateinit var adapter: BaseAdapter

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setContentView(R.layout.activity_main)
        val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        findViewById<TextView>(R.id.greeting).text = greeting(h)
        findViewById<TextView>(R.id.date).text = SimpleDateFormat("EEEE, MMMM d", Locale.getDefault()).format(Date())
        val list = findViewById<ListView>(R.id.list)
        val input = findViewById<EditText>(R.id.input)
        adapter = object : BaseAdapter() {
            override fun getCount() = view.size
            override fun getItem(p: Int) = view[p]
            override fun getItemId(p: Int) = view[p].id
            override fun getView(p: Int, v: View?, g: ViewGroup): View {
                val row = v ?: layoutInflater.inflate(R.layout.item, g, false)
                val t = view[p]
                val tx = row.findViewById<TextView>(R.id.text)
                tx.text = t.text
                tx.paintFlags = if (t.done) tx.paintFlags or Paint.STRIKE_THRU_TEXT_FLAG
                else tx.paintFlags and Paint.STRIKE_THRU_TEXT_FLAG.inv()
                tx.setTextColor(getColor(if (t.done) R.color.mute else R.color.ink))
                row.findViewById<ImageView>(R.id.check)
                    .setImageResource(if (t.done) R.drawable.ic_check_on else R.drawable.ic_check_off)
                row.findViewById<View>(R.id.del).setOnClickListener {
                    tasks.removeAll { it.id == t.id }; commit()
                }
                return row
            }
        }
        list.adapter = adapter
        list.setOnItemClickListener { _, _, p, _ ->
            val id = view[p].id
            tasks = tasks.map { if (it.id == id) it.copy(done = !it.done) else it }.toMutableList(); commit()
        }
        fun add() {
            val s = input.text.toString().trim()
            if (s.isEmpty()) return
            tasks.add(0, Task(System.currentTimeMillis(), s, false))
            input.text.clear(); commit()
        }
        findViewById<View>(R.id.add).setOnClickListener { add() }
        input.setOnEditorActionListener { _, _, _ -> add(); true }
        listOf(R.id.f0, R.id.f1, R.id.f2).forEachIndexed { i, id ->
            findViewById<View>(id).setOnClickListener { filter = i; refresh() }
        }
        findViewById<View>(R.id.clear).setOnClickListener { tasks.removeAll { it.done }; commit() }
    }

    override fun onResume() { super.onResume(); tasks = Store.load(this); refresh() }

    private fun greeting(h: Int) = if (h < 12) "Good morning" else if (h < 18) "Good afternoon" else "Good evening"

    private fun commit() { Store.save(this, tasks); refresh() }

    private fun refresh() {
        view = tasks.filter { filter == 0 || (filter == 2) == it.done }
        val done = tasks.count { it.done }
        findViewById<TextView>(R.id.count).text = "$done/${tasks.size}"
        findViewById<ProgressBar>(R.id.bar).progress = if (tasks.isEmpty()) 0 else done * 100 / tasks.size
        findViewById<TextView>(R.id.left).text =
            if (tasks.size - done > 0) "${tasks.size - done} left" else if (tasks.isNotEmpty()) "All done" else ""
        findViewById<View>(R.id.clear).visibility = if (done > 0) View.VISIBLE else View.INVISIBLE
        val e = findViewById<TextView>(R.id.empty)
        e.visibility = if (view.isEmpty()) View.VISIBLE else View.GONE
        e.text = if (tasks.isEmpty()) "No tasks yet.\nAdd your first one above." else if (filter == 2) "Nothing done yet." else "All clear. Nice work."
        listOf(R.id.f0, R.id.f1, R.id.f2).forEachIndexed { i, id ->
            val t = findViewById<TextView>(id)
            t.setBackgroundResource(if (i == filter) R.drawable.tab_on else 0)
            t.setTextColor(getColor(if (i == filter) R.color.card else R.color.mute))
        }
        adapter.notifyDataSetChanged()
    }
}

package com.example.todo

import android.app.Activity
import android.graphics.Paint
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private var tasks = mutableListOf<Task>()
    private lateinit var adapter: BaseAdapter

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setContentView(R.layout.activity_main)
        val list = findViewById<ListView>(R.id.list)
        val input = findViewById<EditText>(R.id.input)
        adapter = object : BaseAdapter() {
            override fun getCount() = tasks.size
            override fun getItem(p: Int) = tasks[p]
            override fun getItemId(p: Int) = tasks[p].id
            override fun getView(p: Int, v: View?, g: ViewGroup): View {
                val row = v ?: layoutInflater.inflate(R.layout.item, g, false)
                val t = tasks[p]
                val tx = row.findViewById<TextView>(R.id.text)
                val ck = row.findViewById<TextView>(R.id.check)
                tx.text = t.text
                tx.paintFlags = if (t.done) tx.paintFlags or Paint.STRIKE_THRU_TEXT_FLAG
                else tx.paintFlags and Paint.STRIKE_THRU_TEXT_FLAG.inv()
                tx.setTextColor(getColor(if (t.done) R.color.mute else R.color.ink))
                ck.text = if (t.done) "✓" else "○"
                ck.setTextColor(getColor(if (t.done) R.color.acc else R.color.mute))
                return row
            }
        }
        list.adapter = adapter
        list.setOnItemClickListener { _, _, p, _ -> tasks[p] = tasks[p].copy(done = !tasks[p].done); commit() }
        list.setOnItemLongClickListener { _, _, p, _ -> tasks.removeAt(p); commit(); true }
        fun add() {
            val s = input.text.toString().trim()
            if (s.isEmpty()) return
            tasks.add(0, Task(System.currentTimeMillis(), s, false))
            input.text.clear(); commit()
        }
        findViewById<Button>(R.id.add).setOnClickListener { add() }
        input.setOnEditorActionListener { _, _, _ -> add(); true }
    }

    override fun onResume() {
        super.onResume()
        tasks = Store.load(this)
        adapter.notifyDataSetChanged()
    }

    private fun commit() { Store.save(this, tasks); adapter.notifyDataSetChanged() }
}
